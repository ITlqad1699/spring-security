package constant;

/**
 * The type Field names constant.
 */
public class FieldNamesConstant {

    public static final String CUSTOMER_ID = "customerId";

    public static final String USERNAME = "userName";
}
