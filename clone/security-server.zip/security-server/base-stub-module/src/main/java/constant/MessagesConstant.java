package constant;

public class MessagesConstant {
}
