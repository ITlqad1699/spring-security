
export const  AppConstants = {
    CONTACT_API_URL : "/contact",
    LOGIN_API_URL : "/user",
    ACCOUNT_API_URL : "/my-account",
    BALANCE_API_URL : "/my-balance",
    LOANS_API_URL : "/my-loans",
    CARDS_API_URL : "/my-cards",
    NOTICES_API_URL : "/notices",
    REGISTER_API_URL : "/register"
}
